import React, { useEffect, useRef, useCallback } from 'react';
import JSZip from 'jszip';
import { DebateCard, DebateDocument } from '../types';
import { escapeHtml, stripTagsToText } from '../utils/docxProcessor';

declare global {
  interface Window {
    docx?: { renderAsync: Function };
    docxPreview?: { renderAsync: Function };
  }
}

interface CardPreviewProps {
  card: DebateCard | null;
  docs: Map<string, DebateDocument>;
  onStepSelection: (direction: number) => void;
  showToast: (message: string) => void;
}

async function buildCardDocx(card: DebateCard, doc: DebateDocument, bodyOnly = false): Promise<Blob> {
  const newZip = new JSZip();
  for (const [path, entry] of Object.entries(doc.zipData.files) as any) {
    if (path === 'word/document.xml') continue;
    if (entry.dir) continue;
    newZip.file(path, await entry.async('uint8array'));
  }
  newZip.file('word/document.xml', buildCardXml(card, doc, bodyOnly));
  return newZip.generateAsync({ type: 'blob' });
}

function buildCardXml(card: DebateCard, doc: DebateDocument, bodyOnly = false): string {
  const keep = new Set<number>();
  if (!bodyOnly) {
    if (card.tagParaIndex !== null) keep.add(card.tagParaIndex);
    if (card.citeParaIndex !== null) keep.add(card.citeParaIndex);
  }
  card.bodyParaIndices.forEach(i => keep.add(i));
  const bodyParas = doc.paragraphsXml
    .map((xml, i) => keep.has(i) ? xml : null)
    .filter(Boolean).join('');
  const sectPrMatch = doc.rawXml.match(/<w:sectPr\b[\s\S]*?<\/w:sectPr>/);
  const sectPr = sectPrMatch ? sectPrMatch[0] : '';
  return doc.rawXml.replace(/<w:body\b[^>]*>[\s\S]*<\/w:body>/, match => {
    const open = match.match(/^<w:body\b[^>]*>/)![0];
    return `${open}${bodyParas}${sectPr}</w:body>`;
  });
}

function downloadFile(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}

function safeFilename(card: DebateCard, doc: DebateDocument): string {
  const clean = (s: string) => (s || '').replace(/[^a-zA-Z0-9 _-]/g, '').replace(/\s+/g, '_').substring(0, 40);
  return `${clean(doc.shortName).substring(0, 20)}__${clean(card.author)}_${clean(card.tag).substring(0, 30)}.docx`;
}

function inlineComputedStyles(clone: Element, live: Element) {
  const liveEls = live.querySelectorAll('*');
  const cloneEls = clone.querySelectorAll('*');
  const KEEP = ['font-weight', 'font-style', 'text-decoration', 'background-color', 'color', 'font-size', 'font-family'];
  liveEls.forEach((el, i) => {
    if (i >= cloneEls.length) return;
    const computed = window.getComputedStyle(el);
    const additions: string[] = [];
    KEEP.forEach(prop => {
      const val = computed.getPropertyValue(prop);
      if (!val || val === 'none' || val === 'normal' || val === 'rgba(0, 0, 0, 0)' || val === 'transparent') return;
      if (prop === 'background-color' && (val === 'rgb(255, 255, 255)' || val === 'rgba(0, 0, 0, 0)')) return;
      if (prop === 'color' && val === 'rgb(0, 0, 0)') return;
      additions.push(`${prop}:${val}`);
    });
    if (additions.length) (cloneEls[i] as HTMLElement).style.cssText += ';' + additions.join(';');
  });
}

async function writeClipboard(plainText: string, html: string | null) {
  try {
    if (html && (window as any).ClipboardItem && navigator.clipboard?.write) {
      const item = new (window as any).ClipboardItem({
        'text/plain': new Blob([plainText], { type: 'text/plain' }),
        'text/html': new Blob([html], { type: 'text/html' }),
      });
      await navigator.clipboard.write([item]);
      return;
    }
    if (navigator.clipboard?.writeText) { await navigator.clipboard.writeText(plainText); return; }
  } catch { /* fall through */ }
  const ta = document.createElement('textarea');
  ta.value = plainText;
  ta.style.cssText = 'position:fixed;opacity:0;top:0;left:0;';
  document.body.appendChild(ta); ta.select();
  try { document.execCommand('copy'); } catch { /* ignore */ }
  document.body.removeChild(ta);
}

const CardPreview: React.FC<CardPreviewProps> = ({ card, docs, onStepSelection, showToast }) => {
  const previewBodyRef = useRef<HTMLDivElement>(null);
  const renderTokenRef = useRef(0);
  const currentBlobRef = useRef<Blob | null>(null);

  const renderPreview = useCallback(async (c: DebateCard | null) => {
    const token = ++renderTokenRef.current;
    const bodyEl = previewBodyRef.current;
    if (!bodyEl) return;

    if (!c) {
      bodyEl.innerHTML = `<div class="preview-placeholder"><span class="big">←</span>Select a card from the list to view it here.</div>`;
      currentBlobRef.current = null;
      return;
    }

    const doc = docs.get(c.docId);
    if (!doc) {
      bodyEl.innerHTML = `<div class="preview-placeholder">Source document is no longer available.</div>`;
      return;
    }

    bodyEl.innerHTML = `<div class="preview-loading"><div class="spinner"></div>Rendering card...</div>`;

    let blob: Blob;
    try { blob = await buildCardDocx(c, doc); } catch (err) {
      if (token !== renderTokenRef.current) return;
      bodyEl.innerHTML = `<div class="preview-placeholder">Error building preview: ${escapeHtml(String(err))}</div>`;
      return;
    }
    if (token !== renderTokenRef.current) return;
    currentBlobRef.current = blob;

    const docxLib = window.docx || window.docxPreview;
    if (docxLib?.renderAsync) {
      try {
        const bodyBlob = await buildCardDocx(c, doc, true);
        const arrayBuffer = await bodyBlob.arrayBuffer();
        if (token !== renderTokenRef.current) return;

        const headerEl = document.createElement('div');
        headerEl.className = 'card-header-block';
        if (c.section) { const el = document.createElement('div'); el.className = 'ch-section'; el.textContent = c.section; headerEl.appendChild(el); }
        const tagEl = document.createElement('div'); tagEl.className = 'ch-tag'; tagEl.textContent = c.tag; headerEl.appendChild(tagEl);
        if (c.cite) { const el = document.createElement('div'); el.className = 'ch-cite'; el.textContent = c.cite; headerEl.appendChild(el); }
        if (c.year) { const el = document.createElement('div'); el.className = 'ch-year'; el.textContent = String(c.year); headerEl.appendChild(el); }
        const divider = document.createElement('div'); divider.className = 'ch-divider'; headerEl.appendChild(divider);

        bodyEl.innerHTML = '';
        bodyEl.appendChild(headerEl);
        const bodyContainer = document.createElement('div');
        bodyEl.appendChild(bodyContainer);

        await docxLib.renderAsync(arrayBuffer, bodyContainer, null, {
          className: 'docx', inWrapper: true, ignoreWidth: true, ignoreHeight: true,
          breakPages: false, useBase64URL: true,
          renderHeaders: false, renderFooters: false, renderFootnotes: false, renderEndnotes: false,
        });
        if (token !== renderTokenRef.current) return;
        bodyEl.scrollTop = 0;
        return;
      } catch (err) {
        console.warn('docx-preview failed, falling back:', err);
        if (token !== renderTokenRef.current) return;
      }
    }

    // Fallback plain render
    const doc2 = docs.get(c.docId)!;
    const parts: string[] = [];
    if (c.section) parts.push(`<div style="font-size:11px;text-transform:uppercase;letter-spacing:0.6px;color:var(--color-text-tertiary);margin-bottom:8px;">${escapeHtml(c.section)}</div>`);
    parts.push(`<div style="font-size:16px;font-weight:700;margin-bottom:8px;">${escapeHtml(c.tag)}</div>`);
    if (c.cite) parts.push(`<div style="font-size:12px;font-weight:600;margin-bottom:6px;">${escapeHtml(c.cite)}</div>`);
    if (c.year) parts.push(`<div style="font-size:10px;background:var(--color-background-tertiary);color:var(--color-text-secondary);border-radius:3px;padding:2px 6px;display:inline-block;margin-bottom:12px;">${c.year}</div>`);
    c.bodyParaIndices.forEach(idx => {
      const t = stripTagsToText(doc2.paragraphsXml[idx]);
      if (t) parts.push(`<p style="font-family:var(--font-serif);font-size:13px;margin-bottom:8px;">${escapeHtml(t)}</p>`);
    });
    bodyEl.innerHTML = `<div style="padding:28px 40px;">${parts.join('')}</div>`;
  }, [docs]);

  useEffect(() => { renderPreview(card); }, [card, renderPreview]);

  const handleCopyFormatted = async () => {
    if (!card) { showToast('No card selected'); return; }
    const doc = docs.get(card.docId);
    if (!doc) return;
    const bodyEl = previewBodyRef.current;

    const sectionHtml = card.section ? `<div style="font-family:Arial,sans-serif;font-size:9pt;color:#666;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:6px;">${escapeHtml(card.section)}</div>` : '';
    const tagHtml = `<div style="font-family:Arial,sans-serif;font-size:14pt;font-weight:700;margin-bottom:6px;">${escapeHtml(card.tag)}</div>`;
    const citeHtml = card.cite ? `<div style="font-family:Arial,sans-serif;font-size:10pt;font-weight:700;margin-bottom:10px;">${escapeHtml(card.cite)}</div>` : '';

    let bodyHtml = '';
    if (bodyEl) {
      const bodyContainer = bodyEl.querySelector('.docx-wrapper') || bodyEl.querySelector('div:last-child');
      if (bodyContainer) {
        try {
          const clone = bodyContainer.cloneNode(true) as Element;
          inlineComputedStyles(clone, bodyContainer);
          bodyHtml = clone.innerHTML;
        } catch { bodyHtml = bodyContainer.innerHTML; }
      }
    }

    const plainParts: string[] = [];
    if (card.section) plainParts.push(card.section);
    plainParts.push(card.tag);
    if (card.cite) plainParts.push(card.cite);
    card.bodyParaIndices.forEach(idx => {
      const t = stripTagsToText(doc.paragraphsXml[idx]);
      if (t) plainParts.push(t);
    });
    const plainText = plainParts.join('\n\n');
    const htmlContent = `<div style="font-family:Calibri,Georgia,'Times New Roman',serif;font-size:11pt;line-height:1.4;color:#000;">${sectionHtml}${tagHtml}${citeHtml}<div>${bodyHtml}</div></div>`;

    try {
      await writeClipboard(plainText, htmlContent);
      showToast('Copied formatted — paste into Word or Docs');
    } catch {
      await writeClipboard(plainText, null);
      showToast('Copied plain text (formatted copy unavailable)');
    }
  };

  const handleCopyPlain = async () => {
    if (!card) return;
    const doc = docs.get(card.docId);
    if (!doc) return;
    const parts: string[] = [];
    if (card.section) parts.push(card.section);
    parts.push(card.tag);
    if (card.cite) parts.push(card.cite);
    card.bodyParaIndices.forEach(idx => {
      const t = stripTagsToText(doc.paragraphsXml[idx]);
      if (t) parts.push(t);
    });
    await writeClipboard(parts.join('\n\n'), null);
    showToast('Copied plain text');
  };

  const handleDownload = async () => {
    if (!card) return;
    const doc = docs.get(card.docId);
    if (!doc) return;
    const blob = currentBlobRef.current || await buildCardDocx(card, doc);
    downloadFile(blob, safeFilename(card, doc));
  };

  return (
    <div className="right-pane">
      <div className="preview-toolbar" style={{ display: card ? '' : 'none' }}>
        <button className="primary" onClick={handleCopyFormatted}>Copy formatted</button>
        <button onClick={handleCopyPlain}>Copy plain text</button>
        <button onClick={handleDownload}>Download .docx</button>
        <span className="spacer"></span>
        <button onClick={() => onStepSelection(-1)}>← Prev</button>
        <button onClick={() => onStepSelection(1)}>Next →</button>
      </div>

      <div className="preview-body" ref={previewBodyRef}>
        <div className="preview-placeholder">
          <span className="big">←</span>
          Select a card from the list to view it here.
        </div>
      </div>

      {card && docs.get(card.docId) && (
        <div className="preview-footer">
          <span className="label">Source</span>
          <span className="source-name">{docs.get(card.docId)!.filename}</span>
          <span className="source-section">{card.section || ''}</span>
        </div>
      )}
    </div>
  );
};

export default CardPreview;
